# BNB Smart Chain White Paper

## Revision

* Version 0.1, 2020/04/17, initial publish.
* Version 0.1, 2020/05/25, add Chinese version translated by community members.
* Version 0.1, 2020/11/10, add Filipino version translated by @ricoz
